# rdp
 Personal RDP from Microsoft Azure for 6 hours each session

# Watch the Video to understand
<a href="https://cdn.jwplayer.com/previews/hgy10lTt-r9d6Q8Zw">![How to Get Free Microsoft RDP for Unlimited Times](https://cdn.jsdelivr.net/gh/rialms/rdp@master/dl/watch.gif)</a>
